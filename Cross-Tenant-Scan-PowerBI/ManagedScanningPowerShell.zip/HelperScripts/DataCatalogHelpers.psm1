﻿function Set-AzDataCatalogScanTargetSQLServerBatch
{
    Param
    (
        [Parameter(Mandatory=$true)]
        $ConfigurationFile,
        [Parameter(Mandatory=$true)]
        $IntegrationRuntimeName
    )
	$tsvData = Import-Csv $ConfigurationFile -Delimiter "`t"

	$tsvData | ForEach-Object -Process `
	{ 
	    Write-Host "Trying to create Scan Target -" $_.ScanTargetFriendlyName

	    Set-AzDataCatalogScanTarget `
		   -SQLServerScan `
	 	   -ConnectionStringAuthentication `
		   -ScanTargetFriendlyName $_.ScanTargetFriendlyName `
		   -ConnectionString $_.ConnectionString `
		   -IntegrationRuntimeName $IntegrationRuntimeName
    
	    if ($?)
		{
		    Write-Host "Scan Target creation completed -" $_.ScanTargetFriendlyName
		}
	}
}